**LAPORAN PRAKTIKUM**

**ALGORITMA PEMROGRAMAN 2**

**MODUL 2 -- REVIEW PENGENALAN PEMROGRAMAN**

![](./image1.png){width="2.875in" height="3.5in"}

Arsyaghali Nafiras

109082500068

KELAS S1IF-13-06

**PROGRAM STUDI TEKNIK INFORMATIKA**

**FAKULTAS INFORMATIKA**

**TELKOM UNIVERSITY PURWOKERTO**

**2026**

A.  Dasar Teori

1.Struktur Program Go

2.Tipe Data dan Instruksi Dasar

3.Struktur Kontrol Perulangan

B.  Guided

```{=html}
<!-- -->
```
1.  BodyMassIndex

+-----------------------------------------------------------------------+
| package main                                                          |
|                                                                       |
| import \"fmt\"                                                        |
|                                                                       |
| func main() {                                                         |
|                                                                       |
| var berat, tinggi, bmi float64                                        |
|                                                                       |
| fmt.Print(\"Masukkan berat badan (kg): \")                            |
|                                                                       |
| fmt.Scanln(&berat)                                                    |
|                                                                       |
| fmt.Print(\"Masukkan tinggi badan (m): \")                            |
|                                                                       |
| fmt.Scanln(&tinggi)                                                   |
|                                                                       |
| bmi = berat / (tinggi \* tinggi)                                      |
|                                                                       |
| fmt.Printf(\"Nilai BMI Anda adalah: %.2f\\n\", bmi)                   |
|                                                                       |
| }                                                                     |
+=======================================================================+
+-----------------------------------------------------------------------+

> Output :
>
> ![](./image2.png){width="3.323380358705162in"
> height="0.739686132983377in"}

2.  Target Tabungan

+-----------------------------------------------------------------------+
| package main                                                          |
|                                                                       |
| import \"fmt\"                                                        |
|                                                                       |
| func main() {                                                         |
|                                                                       |
| var target, tabungan, total, hari int                                 |
|                                                                       |
| fmt.Print(\"Masukkan target tabungan: \")                             |
|                                                                       |
| fmt.Scanln(&target)                                                   |
|                                                                       |
| total = 0                                                             |
|                                                                       |
| hari = 0                                                              |
|                                                                       |
| for total \< target {                                                 |
|                                                                       |
| hari++                                                                |
|                                                                       |
| fmt.Printf(\"Masukkan jumlah tabungan hari ke-%d: \", hari)           |
|                                                                       |
| fmt.Scanln(&tabungan)                                                 |
|                                                                       |
| total = total + tabungan                                              |
|                                                                       |
| }                                                                     |
|                                                                       |
| fmt.Printf(\"selamat! target tercapai dalam %d hari\\n\", hari)       |
|                                                                       |
| fmt.Printf(\"Total tabungan anda terkumpul: %d\\n\", total)           |
|                                                                       |
| }                                                                     |
+=======================================================================+
+-----------------------------------------------------------------------+

> Output :
>
> ![](./image3.png){width="4.063066491688539in"
> height="1.156411854768154in"}

3.  \[judul guided 3\]

+-----------------------------------------------------------------------+
| package main                                                          |
|                                                                       |
| import \"fmt\"                                                        |
|                                                                       |
| func main() {                                                         |
|                                                                       |
| var usia, harga int                                                   |
|                                                                       |
| fmt.Print(\"Masukkan usia penonton: \")                               |
|                                                                       |
| fmt.Scanln(&usia)                                                     |
|                                                                       |
| if usia \< 12 {                                                       |
|                                                                       |
| harga = 30000                                                         |
|                                                                       |
| } else if usia \>= 12 && usia \<= 17 {                                |
|                                                                       |
| harga = 40000                                                         |
|                                                                       |
| } else {                                                              |
|                                                                       |
| harga = 50000                                                         |
|                                                                       |
| }                                                                     |
|                                                                       |
| fmt.Printf(\"Usia penonton: %d tahun\\n\", usia)                      |
|                                                                       |
| fmt.Printf(\"Harga tiket yang harus dibayar: Rp%d\\n\", harga)        |
|                                                                       |
| }                                                                     |
+=======================================================================+
+-----------------------------------------------------------------------+

> Output :
>
> ![](./image4.png){width="3.979722222222222in"
> height="0.718850612423447in"}

C.  Unguided

```{=html}
<!-- -->
```
1.  Soal Unguided 1

> Tahun kabisat adalah tahun yang habis dibagi 400 atau habis dibagi 4
> tetapi tidak habis dibagi 100. Buatlah sebuah program yang menerima
> input sebuah bilangan bulat dan memeriksa apakah bilangan tersebut
> merupakan tahun kabisat (true) atau bukan (false). Lakukan pengecekan
> apakah tahun 2000, 1974, 2106, 1876 merupakan tahun kabisat atau
> bukan!
>
> Jawaban :

+-----------------------------------------------------------------------+
| package main                                                          |
|                                                                       |
| import \"fmt\"                                                        |
|                                                                       |
| func main() {                                                         |
|                                                                       |
| var tahun int                                                         |
|                                                                       |
| var kabisat bool                                                      |
|                                                                       |
| fmt.Print(\"Masukkan tahun: \")                                       |
|                                                                       |
| fmt.Scanln(&tahun)                                                    |
|                                                                       |
| kabisat = (tahun%400 == 0) \|\| (tahun%4 == 0 && tahun%100 != 0)      |
|                                                                       |
| fmt.Printf(\"kabisat: %t\\n\", kabisat)                               |
|                                                                       |
| }                                                                     |
+=======================================================================+
+-----------------------------------------------------------------------+

> Output :
>
> ![](./image5.png){width="2.5836942257217848in"
> height="2.8545647419072617in"}
>
> Penjelasan :

-   Variabel tahun integer dan kabisat Boolean

-   Operasi (tahun%400 == 0) yaitu jika variabel tahun habis dibagi oleh
    400 maka akan bernilai true

-   Operasi (tahun%4 == 0 && tahun%100 != 0) yaitu jika tahun habis
    dibagi oleh 4 dan tahun tidak habis dibagi oleh 100 maka bernilai
    true

-   Jika dua-duanya atau salah satu saja benar maka true. Tetapi jika
    semuanya bernilai salah maka false

2.  Soal Unguided 2

> Siswa kelas IPA di salah satu sekolah menengah atas di Indonesia
> sedang mengadakan praktikum kimia. Di setiap percobaan akan
> menggunakan 4 tabung reaksi, yang mana susunan warna cairan di setiap
> tabung akan menentukan hasil percobaan. Siswa diminta untuk mencatat
> hasil percobaan tersebut. Percobaan dikatakan berhasil apabila susunan
> warna zat cair pada gelas 1 hingga gelas 4 secara berturutan adalah
> 'merah', 'kuning', 'hijau', dan 'ungu' selama 5 kali percobaan
> berulang. Buatlah sebuah program yang menerima input berupa warna dari
> ke 4 gelas reaksi sebanyak 5 kali percobaan. Kemudian program akan
> menampilkan true apabila urutan warna sesuai dengan informasi yang
> diberikan pada paragraf sebelumnya, dan false untuk urutan warna
> lainnya.
>
> Jawaban :

+-----------------------------------------------------------------------+
| package main                                                          |
|                                                                       |
| import (                                                              |
|                                                                       |
| \"fmt\"                                                               |
|                                                                       |
| \"strings\"                                                           |
|                                                                       |
| )                                                                     |
|                                                                       |
| func main() {                                                         |
|                                                                       |
| target := \[4\]string{\"merah\", \"kuning\", \"hijau\", \"ungu\"}     |
|                                                                       |
| Percobaan := true                                                     |
|                                                                       |
| for i := 1; i \<= 5; i++ {                                            |
|                                                                       |
| var g1, g2, g3, g4 string                                             |
|                                                                       |
| fmt.Printf(\"Percobaan %d: \", i)                                     |
|                                                                       |
| \_, err := fmt.Scanln(&g1, &g2, &g3, &g4)                             |
|                                                                       |
| if err != nil {                                                       |
|                                                                       |
| Percobaan = false                                                     |
|                                                                       |
| break                                                                 |
|                                                                       |
| }                                                                     |
|                                                                       |
| inputUser := \[4\]string{                                             |
|                                                                       |
| strings.ToLower(g1),                                                  |
|                                                                       |
| strings.ToLower(g2),                                                  |
|                                                                       |
| strings.ToLower(g3),                                                  |
|                                                                       |
| strings.ToLower(g4),                                                  |
|                                                                       |
| }                                                                     |
|                                                                       |
| if inputUser != target {                                              |
|                                                                       |
| Percobaan = false                                                     |
|                                                                       |
| }                                                                     |
|                                                                       |
| }                                                                     |
|                                                                       |
| fmt.Printf(\"Berhasil: %t\\n\", Percobaan)                            |
|                                                                       |
| }                                                                     |
+=======================================================================+
+-----------------------------------------------------------------------+

> Output :
>
> ![](./image6.png){width="4.448537839020123in"
> height="1.4377001312335957in"}
>
> Penjelasan :

-   target := \[4\]string{\"merah\", \"kuning\", \"hijau\", \"ungu\"}
    sebagai penentu keberhasilan yang jika berhasil maka hasilnya true.

-   for i := 1; i \<= 5; i++ { program yang meminta percobaan dilakukan
    5 kali secara berulang.

-   var g1, g2, g3, g4 string

> fmt.Scanln(&g1, &g2, &g3, &g4)
>
> sebagai penginput nilai dari variable g1, g2, g3, g4

-   inputUser := \[4\]string{ sebagai tempat penyimpanan sementara.

-   if inputUser != target {

> Percobaan = false
>
> If Adalah operasi jika,yang mana jika inputuser tidak sama dengan
> target maka percobaan bernilai False.

-   [\"strings\"]{.underline} dan [strings.ToLower Adalah program yang
    meniadakan besar kecilnya suatu huruf sehingga jika user menulisnya
    menggunakan huruf besar maka akan tetap bernilai true dengan syarat
    warna yang dimasukkan sama dengan variable target.]{.underline}

3.  Soal Unguided 3

> PT POS membutuhkan aplikasi perhitungan biaya kirim berdasarkan berat
> parsel. Maka, buatlah program BiayaPos untuk menghitung biaya
> pengiriman tersebut dengan ketentuan sebagai berikut! Dari berat
> parsel (dalam gram), harus dihitung total berat dalam kg dan sisanya
> (dalam gram). Biaya jasa pengiriman adalah Rp. 10.000,- per kg. Jika
> sisa berat lebih dari 500 gram, maka tambahan biaya kirim hanya Rp.
> 5,- per gram saja. Tetapi jika sisa berat kurang dari 500 gram, maka
> tambahan biaya akan dibebankan sebesar Rp. 15,- per gram. Sisa berat
> (yang kurang dari 1kg) digratiskan biayanya apabila total berat
> ternyata lebih dari 10kg. Buatlah detail perhitungan yang meliputi
> detail berat, detail biaya, dan total biaya apabila berat parsel yang
> dikirim adalah 8500 gram, 9250 gram, dan 11750 gram
>
> Jawaban :

+-----------------------------------------------------------------------+
| package main                                                          |
|                                                                       |
| import \"fmt\"                                                        |
|                                                                       |
| func main() {                                                         |
|                                                                       |
| var beratTotalGram int                                                |
|                                                                       |
|     fmt.Print(\"Masukkan total berat (gram): \")                      |
|                                                                       |
|     fmt.Scanf(\"%d\", &beratTotalGram)                                |
|                                                                       |
|     fmt.Println(\"===== Detail Perhitungan =====\")                   |
|                                                                       |
|     const HargaPerKg = 10000                                          |
|                                                                       |
|     kg := beratTotalGram / 1000                                       |
|                                                                       |
|     sisaGram := beratTotalGram % 1000                                 |
|                                                                       |
|     biayaKg := kg \* HargaPerKg                                       |
|                                                                       |
|     var biayaGram int                                                 |
|                                                                       |
|     if kg \> 10 {                                                     |
|                                                                       |
|         biayaGram = 0                                                 |
|                                                                       |
|     } else {                                                          |
|                                                                       |
|         if sisaGram \>= 500 {                                         |
|                                                                       |
|             biayaGram = sisaGram \* 5                                 |
|                                                                       |
|         } else {                                                      |
|                                                                       |
|             biayaGram = sisaGram \* 15                                |
|                                                                       |
|         }                                                             |
|                                                                       |
|     }                                                                 |
|                                                                       |
|     totalBiaya := biayaKg + biayaGram                                 |
|                                                                       |
|     fmt.Printf(\"Detail Berat: %d kg + %d gr\\n\", kg, sisaGram)      |
|                                                                       |
|     fmt.Printf(\"Detail Biaya: Rp. %d (kg) + Rp. %d (gr)\\n\",        |
| biayaKg, biayaGram)                                                   |
|                                                                       |
|     fmt.Printf(\"Total Biaya : Rp. %d\\n\", totalBiaya)               |
|                                                                       |
|                                                                       |
| fmt.Println(\"\-\-\-\-\                                               |
| -\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\--\") |
+=======================================================================+
+-----------------------------------------------------------------------+

> Output :
>
> ![](./image7.png){width="6.198781714785651in"
> height="5.063206474190726in"}
>
> Penjelasan :

-   Logika konversi berat yaitu operasi pembagi (/) dan modulo (%).
    Pembagian untuk menghitung kg sedangkan modulo untuk menghitung
    gram.

-   if kg \> 10 {

> biayaGram = 0
>
> } else {
>
> if sisaGram \>= 500 {
>
> biayaGram = sisaGram \* 5
>
> } else {
>
> biayaGram = sisaGram \* 15
>
> }
>
> Program diatas sebagai logika penghitung biaya kirim gram:
>
> Kondisi kg \> 10 digratiskan lalu jika sisa \>= 500gr, dikalikan **Rp
> 5**. Dan jika
>
> sisa \< 500, dikalikan **Rp 15**.

D.  Kesimpulan

Kesimpulannya terdapat pengulangan for, if-else, structur golang,
operator logika seperti +, -, \*, / dan lain-lain yang mana sangat
diperlukan dalam pemrograman. Lalu tipe data seperti integer, string,
char, Boolean, dan lain lain yang mana memiliki kegunaannya masing
masing.
